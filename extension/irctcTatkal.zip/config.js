FORM_DETAILS = 
        
{
    passengers: [
        {
            name: "Virat Kohli",
            age: "29",
            gender: 'M', //'M'/'F'
            berth: "SL", // 'SL','SU','UB','MB','LB'
            senior: false, 
            id_type: "DRIVING_LICENSE",
            id: "DL-00000000000000",
            meal: 'V' // 'V'/'N'
            
        },
        {
            name: "Anushka Sharma",
            age: "28",
            gender: 'F', //'M'/'F'
            berth: "SU", // 'SL','SU','UB','MB','LB'
            senior: false, 
            id_type: "NULL_IDCARD", // 'NULL_IDCARD'/'DRIVING_LICENSE'/'PASSPORT'/'PANCARD'/''
            id: "",
            meal: 'V' // 'V'/'N'
       },
       {
            name: "Amitabh Bacchan",
            age: "60",
            gender: 'M', //'M'/'F'
            berth: "SU", // 'SL','SU','UB','MB','LB'
            senior: true, 
            id_type: "NULL_IDCARD", // 'NULL_IDCARD'/'DRIVING_LICENSE'/'PASSPORT'/'PANCARD'/''
            id: "",
            meal: 'V' // 'V'/'N'           
       }
    ],
    mobile: "9999999999",
    payment_type: 'debit',
    bank: "citi",
    
    card_number: "0000000000000000",
    card_expiry: "02/18",
    card_cvv: "000",
    card_ipin: ''
            
};
